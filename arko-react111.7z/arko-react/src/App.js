import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import { useEffect, useRef, useState } from "react";

const API_URL = "http://localhost/public";
const CORS_MODE = "cors";

const Success = ({ message }) => {
  return (
    <div className="alert alert-success" role="alert">
      {message}
    </div>
  );
};

const Error = ({ message }) => {
  return (
    <div className="alert alert-danger" role="alert">
      {message}
    </div>
  );
};

function Login() {
  const loginInput = useRef(null);
  const passwordInput = useRef(null);
  const [status, setStatus] = useState("none");

  const authLogin = () => {
    const login = loginInput.current.value;
    const password = passwordInput.current.value;

    fetch(`${API_URL}/api/user/login`, {
      method: "POST",
      mode: CORS_MODE,
      headers: new Headers({
        "Content-Type": "application/json",
        Accept: "application/json",
      }),
      body: JSON.stringify({
        login: login,
        password: password,
      }),
    })
      .then((data) => data.json())
      .then((json) => {
        if (json.error) {
          setStatus("error");
        } else {
          setStatus("success");
          localStorage.setItem("token", json.data.token);
        }
      });
  };

  return (
    <div className="container">
      <div className="row">
        <div className="mb-3">
          <label htmlFor="loginform" className="form-label">
            Login
          </label>
          <input
            ref={loginInput}
            type="text"
            className="form-control"
            id="loginform"
            placeholder="admin"
          />
        </div>
        <div className="mb-3">
          <label htmlFor="passwordform" className="form-label">
            Password
          </label>
          <input
            ref={passwordInput}
            type="password"
            className="form-control"
            id="passwordform"
            placeholder="admin"
          />
        </div>

        {status === "success" ? (
          <Success message="Успешный вход в учетную запись" />
        ) : status === "error" ? (
          <Error message="Был веден не верный пароль" />
        ) : (
          <p></p>
        )}

        <button
          onClick={() => authLogin()}
          type="button"
          className="btn btn-primary"
        >
          Войти
        </button>
      </div>
    </div>
  );
}

function Logout() {
  return (
    <div className="container">
      <div className="row">
        <button
          type="button"
          onClick={() =>
            localStorage.getItem("token")
              ? localStorage.setItem("token", "")
              : alert("Вы не вошли в учетную запись")
          }
          className="btn btn-primary"
        >
          Выйти из учетной записи
        </button>
      </div>
    </div>
  );
}


function UsersTable({ users, toggle }) {
  const [table, setTable] = useState(null);
  useEffect(() => {
    setTable(users);
  }, [users]);

  const Dismissal = (id) => {
    fetch(`${API_URL}/api/user/dismissal`, {
      method: "POST",
      mode: CORS_MODE,
      headers: new Headers({
        "Content-Type": "application/json",
        Accept: "application/json",
        Authorization: `Bearer ${localStorage.getItem("token")}`,
      }),
      body: JSON.stringify({
        id: id,
      }),
    })
      .then((data) => data.json())
      .then((json) => {
        toggle();
      });
  };

  return (
    table && (
      <table className="table">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Имя</th>
            <th scope="col">Роль</th>
            <th scope="col">Логин</th>
            <th scope="col">Статус</th>
            <th scope="col">Уволить</th>
          </tr>
        </thead>
        <tbody>
          {users &&
            users.map((user) => (
              <tr key={user.id}>
                <th scope="row">{user.id}</th>
                <td>{user.name}</td>
                <td>
                  {user.role_id === 1
                    ? "Админ"
                    : user.role_id === 3
                    ? "Рабочий"
                    : "Пользователь"}
                </td>
                <td>{user.login}</td>
                <td>{user.active === 1 ? "Активный" : "Удален"}</td>
                <td>
                  {user.active === 1 ? (
                    <button
                      onClick={() => Dismissal(user.id)}
                      type="button"
                      className="btn btn-danger"
                    >
                      Удалить
                    </button>
                  ) : (
                    ""
                  )}
                </td>
              </tr>
            ))}
        </tbody>
      </table>
    )
  );
}

function UserList() {
  const [users, setUsers] = useState([]);
  const [hide, setHide] = useState(true);
  const [update, setUpdate] = useState(true);

  const toggleUpdate = () => {
    setUpdate(!update);
  };

  useEffect(() => {
    fetch(`${API_URL}/api/user/all`, {
      method: "GET",
      mode: CORS_MODE,
      headers: new Headers({
        "Content-Type": "application/json",
        Accept: "application/json",
        Authorization: `Bearer ${localStorage.getItem("token")}`,
      }),
    })
      .then((data) => data.json())
      .then((json) => {
        if (json.exception) {
          setHide(true);
        } else {
          setUsers(json.data);
          setHide(false);
        }
      });
  }, [update]);
  return (
    <>
      <h2>Все пользователь</h2>
      {hide ? (
        <Error message="Ошибка у вас нету доступа!" />
      ) : (
        <UsersTable users={users} toggle={toggleUpdate} />
      )}
    </>
  );
}

function Registration() {
  const loginInput = useRef(null);
  const nameInput = useRef(null);
  const roleInput = useRef(null);
  const [status, setStatus] = useState("none");
  const [password, setPassword] = useState("");

  const authRegistration = () => {
    const login = loginInput.current.value;
    const name = nameInput.current.value;
    const role = roleInput.current.value;

    fetch(`${API_URL}/api/user/registration`, {
      method: "POST",
      mode: CORS_MODE,
      headers: new Headers({
        "Content-Type": "application/json",
        Accept: "application/json",
        Authorization: `Bearer ${localStorage.getItem("token")}`,
      }),
      body: JSON.stringify({
        name: name,
        login: login,
        role_id: role,
      }),
    })
      .then((data) => data.json())
      .then((json) => {
        if (json.error) {
          setStatus("error");
        } else {
          setStatus("success");
          setPassword(json.data.password);
        }
      });
  };

  return (
    <div className="container">
      <div className="row">
        <h2>Зарегистрировать нового пользователь</h2>
        <div className="mb-3">
          <label htmlFor="nameform" className="form-label">
            Name
          </label>
          <input
            ref={nameInput}
            type="text"
            className="form-control"
            id="nameform"
            placeholder="Adminus"
          />
        </div>
        <div className="mb-3">
          <label htmlFor="loginform" className="form-label">
            Login
          </label>
          <input
            ref={loginInput}
            type="text"
            className="form-control"
            id="loginform"
            placeholder="admin"
          />
        </div>
        <div className="mb-3">
          <label htmlFor="roleform" className="form-label">
            Rold
          </label>
          <input
            ref={roleInput}
            type="number"
            className="form-control"
            id="roleinput"
            placeholder="2"
          />
        </div>

        {status === "success" ? (
          <Success
            message={`Успешный создана запись Пароль от пользователя: ${password}`}
          />
        ) : status === "error" ? (
          <Error message="Ошибка при создание пользователя" />
        ) : (
          <p></p>
        )}

        <button
          onClick={() => authRegistration()}
          type="button"
          className="btn btn-primary"
        >
          Создать
        </button>
      </div>
    </div>
  );
}

function ChangesTable({ changes }) {
  return (
    <table className="table">
      <thead>
        <tr>
          <th scope="col">#</th>
          <th scope="col">Дата начала</th>
          <th scope="col">Дата конца</th>
          <th scope="col">Статус</th>
        </tr>
      </thead>
      <tbody>
        {changes &&
          changes.map((change) => (
            <tr key={change.id}>
              <th scope="row">{change.id}</th>
              <td>{change.date_start}</td>
              <td>{change.date_end}</td>
              <td>{change.closed ? "Закрыта" : "Открыта"}</td>
            </tr>
          ))}
      </tbody>
    </table>
  );
}

function ChangesList() {
  const [changes, setChanges] = useState([]);
  const [hide, setHide] = useState(true);
  useEffect(() => {
    fetch(`${API_URL}/api/change/list`, {
      method: "GET",
      mode: CORS_MODE,
      headers: new Headers({
        "Content-Type": "application/json",
        Accept: "application/json",
        Authorization: `Bearer ${localStorage.getItem("token")}`,
      }),
    })
      .then((data) => data.json())
      .then((json) => {
        console.log(json);
        if (json.exception) {
          setHide(true);
        } else {
          setChanges(json.data);
          setHide(false);
        }
      });

      return () => {
        setChanges([])
      }
  }, []);
  return (
    <>
      <h2>Все смены</h2>
      {hide ? (
        <Error message="Ошибка у вас нету доступа!" />
      ) : (
        <ChangesTable changes={changes} />
      )}
    </>
  );
}

function ChangeCreate() {
  const dataStartInput = useRef(null);
  const dateEndInput = useRef(null);
  const [status, setStatus] = useState("none");

  const createChange = () => {
    const dateStart = dataStartInput.current.value;
    const dateEnd = dateEndInput.current.value;

    fetch(`${API_URL}/api/change/create`, {
      method: "POST",
      mode: CORS_MODE,
      headers: new Headers({
        "Content-Type": "application/json",
        Accept: "application/json",
      }),
      body: JSON.stringify({
        date_start: dateStart,
        date_end: dateEnd,
      }),
    })
      .then((data) => data.json())
      .then((json) => {
        if (json.error) {
          setStatus("error");
        } else {
          setStatus("success");
          console.log(json);
        }
      });
  };

  return (
    <div className="container">
      <div className="row">
        <div className="mb-3">
          <label htmlFor="datastartform" className="form-label">
            Дата начала
          </label>
          <input
            ref={dataStartInput}
            type="date"
            className="form-control"
            id="datastartform"
            placeholder="2020-12-20"
          />
        </div>
        <div className="mb-3">
          <label htmlFor="dataendform" className="form-label">
            Дата конца
          </label>
          <input
            ref={dateEndInput}
            type="date"
            className="form-control"
            id="dataendform"
            placeholder="2020-12-31"
          />
        </div>

        {status === "success" ? (
          <Success message="Успешно создано смена" />
        ) : status === "error" ? (
          <Error message="Ошибка в создание смены" />
        ) : (
          <p></p>
        )}

        <button
          onClick={() => createChange()}
          type="button"
          className="btn btn-primary"
        >
          Войти
        </button>
      </div>
    </div>
  );
}

function Comment({ card }) {
  return (
    <tr>
      <th scope="row">{card.id}</th>
      <td>{card.user_id}</td>
      <td>{card.order_id}</td>
      <td>{card.text}</td>
    </tr>
  );
}

function Comments() {
  const [comments, setComments] = useState([]);
  useEffect(() => {
    fetch(`${API_URL}/api/comment/all`, {
      method: "GET",
      mode: CORS_MODE,
      headers: new Headers({
        "Content-Type": "application/json",
        Accept: "application/json",
        Authorization: `Bearer ${localStorage.getItem("token")}`,
      }),
    })
      .then((data) => data.json())
      .then((json) => setComments(json.data))
      .catch(() => alert("Ошибка! Возможно вы не вошли в учетную запись"));
  }, []);
  return (
    <>
      <h2>Коментарии пользователей</h2>
      <table className="table">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Пользователь</th>
            <th scope="col">Заказ</th>
            <th scope="col">Текст</th>
          </tr>
        </thead>
        <tbody>
          {comments.map((comment) => (
            <Comment key={comment.id} card={comment} />
          ))}
        </tbody>
      </table>
    </>
  );
}

function CreateComment() {
  const userIdInput = useRef(null);
  const orderIdInput = useRef(null);
  const textInput = useRef(null)
  const [status, setStatus] = useState("none");

  const authRegistration = () => {
    const login = userIdInput.current.value;
    const name = textInput.current.value;

    fetch(`${API_URL}/api/user/registration`, {
      method: "POST",
      mode: CORS_MODE,
      headers: new Headers({
        "Content-Type": "application/json",
        Accept: "application/json",
        Authorization: `Bearer ${localStorage.getItem("token")}`,
      }),
      body: JSON.stringify({
        name: name,
        login: login,
      }),
    })
      .then((data) => data.json())
      .then((json) => {
        if (json.error) {
          setStatus("error");
        } else {
          setStatus("success");
        }
      });
  };

  return (
    <div className="container">
      <div className="row">
        <h2>Создание коментария</h2>
        <div className="mb-3">
          <label htmlFor="userform" className="form-label">
            User ID
          </label>
          <input
            ref={userIdInput}
            type="text"
            className="form-control"
            id="userform"
            placeholder="Adminus"
          />
        </div>
        <div className="mb-3">
          <label htmlFor="orderform" className="form-label">
            Order ID
          </label>
          <input
            ref={orderIdInput}
            type="text"
            className="form-control"
            id="orderform"
            placeholder="Adminus"
          />
        </div>
        <div className="mb-3">
          <label htmlFor="textform" className="form-label">
            Text
          </label>
          <textarea ref={textInput}
            type="text"
            className="form-control"
            id="textform"/>
        </div>

        {status === "success" ? (
          <Success
            message={`Успешный создана запись Пароль от пользователя:`}
          />
        ) : status === "error" ? (
          <Error message="Ошибка при создание пользователя" />
        ) : (
          <p></p>
        )}

        <button
          onClick={() => authRegistration()}
          type="button"
          className="btn btn-primary"
        >
          Создать
        </button>
      </div>
    </div>
  );
}

function Submit() {
  const userIdInput = useRef(null);
  const textInput = useRef(null);
  const [status, setStatus] = useState("none");

  const authRegistration = () => {
    const login = userIdInput.current.value;
    const name = textInput.current.value;

    fetch(`${API_URL}/api/user/registration`, {
      method: "POST",
      mode: CORS_MODE,
      headers: new Headers({
        "Content-Type": "application/json",
        Accept: "application/json",
        Authorization: `Bearer ${localStorage.getItem("token")}`,
      }),
      body: JSON.stringify({
        name: name,
        login: login,
      }),
    })
      .then((data) => data.json())
      .then((json) => {
        if (json.error) {
          setStatus("error");
        } else {
          setStatus("success");
        }
      });
  };

  return (
    <div className="container">
      <div className="row">
        <h2>Создание задачи</h2>
        <div className="mb-3">
          <label htmlFor="userform" className="form-label">
            User ID
          </label>
          <input
            ref={userIdInput}
            type="text"
            className="form-control"
            id="userform"
            placeholder="Adminus"
          />
        </div>
        <div className="mb-3">
          <label htmlFor="textform" className="form-label">
            Text
          </label>
          <textarea ref={textInput}
            type="text"
            className="form-control"
            id="textform"/>
        </div>

        {status === "success" ? (
          <Success
            message={`Успешный создана запись Пароль от пользователя:`}
          />
        ) : status === "error" ? (
          <Error message="Ошибка при создание пользователя" />
        ) : (
          <p></p>
        )}

        <button
          onClick={() => authRegistration()}
          type="button"
          className="btn btn-primary"
        >
          Создать
        </button>
      </div>
    </div>
  );
}

function OrdersTable({orders, toggle}) {
  return (
    <></>
  )
}

function OrdersList() {
  const [orders, setOrders] = useState([]);
  const [hide, setHide] = useState(true);
  const [update, setUpdate] = useState(true);

  const toggleUpdate = () => {
    setUpdate(!update);
  };

  useEffect(() => {
    fetch(`${API_URL}/order/orders/all`, {
      method: "GET",
      mode: CORS_MODE,
      headers: new Headers({
        "Content-Type": "application/json",
        Accept: "application/json",
        Authorization: `Bearer ${localStorage.getItem("token")}`,
      }),
    })
      .then((data) => data.json())
      .then((json) => {
        if (json.exception) {
          setHide(true);
        } else {
          console.log(json)
          // setOrders(json.data);
          setHide(false);
        }
      });
  }, [update]);
  return (
    <>
      <h2>Все задачи</h2>
      {hide ? (
        <Error message="Ошибка у вас нету доступа!" />
      ) : (
        <OrdersTable orders={orders} toggle={toggleUpdate} />
      )}
    </>
  );
}

function Profile() {
  const [user, setUser] = useState({});
  useEffect(() => {
    fetch(`${API_URL}/api/user/you`, {
      method: "GET",
      mode: CORS_MODE,
      headers: new Headers({
        "Content-Type": "application/json",
        Accept: "application/json",
        Authorization: `Bearer ${localStorage.getItem("token")}`,
      }),
    })
      .then((data) => data.json())
      .then((json) => setUser(json.user))
      .catch(() => alert("Ошибка! Возможно вы не вошли в учетную запись"));
  }, []);
  return (
    <div className="container">
      <div className="row">
        {user && user.role_id === 1 ? (
          <>
            <h2>Добро пожаловать, {user.name}!</h2>
            <UserList />
            <Registration />
            <ChangesList />
            <ChangeCreate />
          </>
        ) : user && user.role_id === 2 ? (
          <>
            <h2>Добро пожаловать, {user.name}!</h2>
            <Comments />
            <CreateComment />
            <Submit />
          </>
        ) : user && user.role_id === 3 ? (
          <>
            <h2>Добро пожаловать, {user.name}!</h2>
            <OrdersList />
          </>
        ) : (
          <Error message="Ошибка! У вас нету доступа." />
        )}
      </div>
    </div>
  );
}

function App() {
  const [page, setPage] = useState("home");
  const [flag, setFlag] = useState(false);
  if (!flag) {
    if (localStorage.getItem("page")) setPage(localStorage.getItem("page"));
    setFlag(true);
  }
  return (
    <div className="App">
      <header>
        <button
          type="button"
          onClick={() => {
            setPage("login");
            localStorage.setItem("page", "login");
          }}
          className="btn btn-primary"
        >
          Login
        </button>
        <button
          type="button"
          onClick={() => {
            setPage("logout");
            localStorage.setItem("page", "logout");
          }}
          className="btn btn-primary"
        >
          Logout
        </button>
        <button
          type="button"
          onClick={() => {
            setPage("profile");
            localStorage.setItem("page", "profile");
          }}
          className="btn btn-primary"
        >
          Profile
        </button>
        <p>Page: /{page}</p>
      </header>

      {page === "login" ? (
        <Login />
      ) : page === "logout" ? (
        <Logout />
      ) : page === "profile" ? (
        <Profile />
      ) : (
        <h1>Welcome, Home</h1>
      )}
    </div>
  );
}

export default App;
