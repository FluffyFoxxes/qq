import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { useEffect, useRef, useState } from 'react';

const Success = ({ message }) => {
  return (
    <div className="alert alert-success" role="alert">
      {message}
    </div>
  )
}

const Error = ({ message }) => {
  return (
    <div className="alert alert-danger" role="alert">
      {message}
    </div>
  )
}

function Login() {
  const loginInput = useRef(null)
  const passwordInput = useRef(null)
  const [status, setStatus] = useState("none")



  const authLogin = () => {
    const login = loginInput.current.value
    const password = passwordInput.current.value

    fetch("http://localhost:8000/api/user/login", {
      method: "POST",
      mode: "cors",
      headers: new Headers(
        {
          "Content-Type": "application/json",
          "Accept": "application/json"
        }
      ),
      body: JSON.stringify({
        login: login,
        password: password
      })
    }).then(data => data.json())
      .then(json => {
        if (json.error) {
          setStatus("error")
        } else {
          setStatus("success")
          localStorage.setItem("token", json.data.token)
        }
      })
  }

  return (
    <div className='container'>
      <div className='row'>
        <div className="mb-3">
          <label htmlFor="loginform" className="form-label">Login</label>
          <input ref={loginInput} type="text" className="form-control" id="loginform" placeholder="admin" />
        </div>
        <div className="mb-3">
          <label htmlFor="passwordform" className="form-label">Password</label>
          <input ref={passwordInput} type="password" className="form-control" id="passwordform" placeholder="admin" />
        </div>

        {status === "success" ? <Success message="Успешный вход в учетную запись" /> : status === "error" ? <Error message="Был веден не верный пароль" /> : <p></p>}

        <button onClick={() => authLogin()} type='button' className="btn btn-primary">Войти</button>
      </div>
    </div>
  )
}

function Logout() {
  return (
    <div className='container'>
      <div className='row'>
        <button type="button" onClick={() => localStorage.getItem("token") ? localStorage.setItem("token", "") : alert("Вы не вошли в учетную запись")} className="btn btn-primary">Выйти из учетной записи</button>
      </div>
    </div>
  )
}

function Dismissal(id) {
  fetch("http://localhost:8000/api/user/dismissal", {
    method: "POST",
    mode: "cors",
    headers: new Headers(
      {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "Authorization": `Bearer ${localStorage.getItem("token")}`
      }
    ),
    body: JSON.stringify({
      id: id
    })
  }).then(data => data.json())
    .then(json => {
      console.log(json)
    })
}

function UsersTable({ users }) {
  return (
    <table className="table">
      <thead>
        <tr>
          <th scope="col">#</th>
          <th scope="col">Имя</th>
          <th scope="col">Роль</th>
          <th scope="col">Логин</th>
          <th scope='col'>Статус</th>
          <th scope='col'>Уволить</th>
        </tr>
      </thead>
      <tbody>
        {users && users.map(user => (
          <tr key={user.id}>
            <th scope='row'>{user.id}</th>
            <td>{user.name}</td>
            <td>{user.role_id === 1 ? "Админ" : user.role_id === 3 ? "Рабочий" : "Пользователь"}</td>
            <td>{user.login}</td>
            <td>{user.active === 1 ? "Активный" : "Удален"}</td>
            <td>{user.active === 1 ? <button onClick={() => Dismissal(user.id)} type="button" className="btn btn-danger">Удалить</button> : ""}</td>
          </tr>
        ))}
      </tbody>
    </table>
  )
}

function UserList() {
  const [users, setUsers] = useState([])
  const [hide, setHide] = useState(true)
  useEffect(() => {
    fetch("http://localhost:8000/api/user/all", {
      method: "GET",
      mode: "cors",
      headers: new Headers(
        {
          "Content-Type": "application/json",
          "Accept": "application/json",
          "Authorization": `Bearer ${localStorage.getItem("token")}`
        }
      )
    }).then(data => data.json())
      .then(json => {
        if (json.exception) {
          setHide(true)
        } else {
          setUsers(json.data)
          setHide(false)
        }
      })
  }, [])
  return (
    <>
      <h2>Все пользователь</h2>
      {hide ? <Error message="Ошибка у вас нету доступа!" /> : <UsersTable users={users} />}
    </>
  )
}

function Registration() {
  const loginInput = useRef(null)
  const nameInput = useRef(null)
  const roleInput = useRef(null)
  const [status, setStatus] = useState("none")
  const [password, setPassword] = useState("")



  const authRegistration = () => {
    const login = loginInput.current.value
    const name = nameInput.current.value
    const role = roleInput.current.value

    fetch("http://localhost:8000/api/user/registration", {
      method: "POST",
      mode: "cors",
      headers: new Headers(
        {
          "Content-Type": "application/json",
          "Accept": "application/json",
          "Authorization": `Bearer ${localStorage.getItem("token")}`
        }
      ),
      body: JSON.stringify({
        name: name,
        login: login,
        role_id: role
      })
    }).then(data => data.json())
      .then(json => {
        if (json.error) {
          setStatus("error")
        } else {
          setStatus("success")
          setPassword(json.data.password)
        }
      })
  }

  return (
    <div className='container'>
      <div className='row'>
        <h2>Зарегистрировать нового пользователь</h2>
        <div className="mb-3">
          <label htmlFor="nameform" className="form-label">Name</label>
          <input ref={nameInput} type="text" className="form-control" id="nameform" placeholder="Adminus" />
        </div>
        <div className="mb-3">
          <label htmlFor="loginform" className="form-label">Login</label>
          <input ref={loginInput} type="text" className="form-control" id="loginform" placeholder="admin" />
        </div>
        <div className="mb-3">
          <label htmlFor="roleform" className="form-label">Rold</label>
          <input ref={roleInput} type="number" className="form-control" id="roleinput" placeholder="2" />
        </div>

        {status === "success" ? <Success message={`Успешный создана запись Пароль от пользователя: ${password}`} /> : status === "error" ? <Error message="Ошибка при создание пользователя" /> : <p></p>}

        <button onClick={() => authRegistration()} type='button' className="btn btn-primary">Создать</button>
      </div>
    </div>
  )
}

function Profile() {
  return (
    <div className='container'>
      <div className='row'>
        <UserList />
        <Registration />
      </div>
    </div >
  )
}


function App() {
  const [page, setPage] = useState("home")
  const [flag, setFlag] = useState(false)
  if (!flag) {
    if (localStorage.getItem("page"))
      setPage(localStorage.getItem("page"))
    setFlag(true)
  }
  return (
    <div className="App">
      <header>
        <button type="button" onClick={() => { setPage("login"); localStorage.setItem("page", "login"); }} className="btn btn-primary">Login</button>
        <button type="button" onClick={() => { setPage("logout"); localStorage.setItem("page", "logout"); }} className="btn btn-primary">Logout</button>
        <button type="button" onClick={() => { setPage("profile"); localStorage.setItem("page", "profile"); }} className="btn btn-primary">Profile</button>
        <p>Page: /{page}</p>
      </header>

      {page === "login" ? <Login /> : page === "logout" ? <Logout /> : page === "profile" ? <Profile /> : <h1>Welcome, Home</h1>}
    </div>
  );
}

export default App;
